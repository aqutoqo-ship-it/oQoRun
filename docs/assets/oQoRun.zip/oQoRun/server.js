const express = require('express');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;
const LLAMA_PORT = 8081;

// Path configuration
const LLAMA_SERVER_PATH = path.join(__dirname, 'llama-b8101-bin-win-cpu-x64', 'llama-server.exe');
const MODELS_DIR = path.join(__dirname, 'models');

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

let currentProcess = null;
let currentModelInfo = null;

// Helper: Recursively find .gguf files
function findGGUFFiles(dir, fileList = []) {
    if (!fs.existsSync(dir)) return fileList;

    const files = fs.readdirSync(dir);

    files.forEach(file => {
        // Exclude large directories
        if (file === 'node_modules' || file === 'llama-b8101-bin-win-cpu-x64' || file === '.git') return;

        const filePath = path.join(dir, file);
        let stat;
        try { stat = fs.statSync(filePath); } catch (e) { return; }

        if (stat.isDirectory()) {
            findGGUFFiles(filePath, fileList);
        } else if (file.endsWith('.gguf')) {
            if (file.toLowerCase().startsWith('mmproj-')) return;
            fileList.push({
                name: file,
                path: filePath,
                size: (stat.size / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
            });
        }
    });

    return fileList;
}

// API: List Models
app.get('/api/models', (req, res) => {
    // 1. Scan root dir
    let models = findGGUFFiles(__dirname);
    // 2. Scan models subdir (if exists and distinct)
    if (MODELS_DIR !== __dirname) {
        // Filter duplicates if any
        const subdirModels = findGGUFFiles(MODELS_DIR);
        subdirModels.forEach(m => {
            if (!models.find(existing => existing.path === m.path)) {
                models.push(m);
            }
        });
    }
    res.json(models);
});

// API: Get Current Model
app.get('/api/current', (req, res) => {
    if (currentProcess && currentModelInfo) {
        res.json(currentModelInfo);
    } else {
        res.json(null);
    }
});

// Helper: Force kill a process and its children on Windows
function forceKillProcess(proc) {
    if (!proc) return;
    try {
        // Use taskkill with /T (tree) and /F (force) to kill the entire process tree
        execSync(`taskkill /F /T /PID ${proc.pid}`, { stdio: 'ignore' });
        console.log(`Force-killed process tree for PID ${proc.pid}`);
    } catch (e) {
        // Process may already be dead
        console.log(`Process ${proc.pid} already terminated`);
    }
}

// API: Launch Model
app.post('/api/launch', async (req, res) => {
    const { modelPath, gpuLayers, ctxSize, apiKey } = req.body;

    if (!modelPath || !fs.existsSync(modelPath)) {
        return res.status(400).json({ error: 'Invalid model path' });
    }

    // Kill existing process forcefully
    if (currentProcess) {
        console.log('Stopping previous model...');
        forceKillProcess(currentProcess);
        currentProcess = null;
        currentModelInfo = null;

        // Wait for port to be released
        await new Promise(resolve => setTimeout(resolve, 1500));
    }

    console.log(`Launching: ${modelPath}`);
    currentModelInfo = { path: modelPath, name: path.basename(modelPath), apiKey: apiKey || null };

    // Arguments: -m modelPath -c 2048 --port 8081 --host 0.0.0.0
    const args = [
        '-m', modelPath,
        '-c', (ctxSize || '4096').toString(), // Configurable Context
        '--port', LLAMA_PORT.toString(),
        '--host', '0.0.0.0',
        '-ngl', (gpuLayers || '0').toString() // Configurable GPU Layers
    ];

    if (apiKey && apiKey.trim() !== '') {
        args.push('--api-key', apiKey.trim());
    }

    try {
        const modelDir = path.dirname(modelPath);
        const dirFiles = fs.readdirSync(modelDir);
        const mmprojFile = dirFiles.find(f => f.toLowerCase().startsWith('mmproj-') && f.toLowerCase().endsWith('.gguf'));
        if (mmprojFile) {
            console.log(`Auto-detected mmproj file: ${mmprojFile}`);
            args.push('--mmproj', path.join(modelDir, mmprojFile));
        }
    } catch (e) {
        console.error('Error auto-detecting mmproj:', e);
    }

    currentProcess = spawn(LLAMA_SERVER_PATH, args);

    currentProcess.stdout.on('data', (data) => {
        console.log(`[LLAMA]: ${data}`);
    });

    currentProcess.stderr.on('data', (data) => {
        console.error(`[LLAMA ERR]: ${data}`);
    });

    currentProcess.on('close', (code) => {
        console.log(`llama-server exited with code ${code}`);
        currentProcess = null;
        currentModelInfo = null;
    });

    res.json({ status: 'launching', port: LLAMA_PORT });
});

// API: Stop Model
app.post('/api/stop', (req, res) => {
    if (currentProcess) {
        console.log('User requested to stop model...');
        forceKillProcess(currentProcess);
        currentProcess = null;
        currentModelInfo = null;
        res.json({ status: 'stopped' });
    } else {
        res.json({ status: 'not_running' });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`AQutoQo UI running at http://localhost:${PORT}`);
    console.log(`LLAMA API will run at http://localhost:${LLAMA_PORT}`);
});
