   QQQQQQQQQQQQQ       QQQQQQQQQQQQQ     RRRRRRRRRRRRRRRRRRRR
  QQQQQQ   QQQQQQ     QQQQQQ   QQQQQQ    RRRRRR       RRRRRRR
 QQQQQQ     QQQQQQ   QQQQQQ     QQQQQQ   RRRRRR       RRRRRRR
 QQQQQQ     QQQQQQ   QQQQQQ     QQQQQQ   RRRRRRRRRRRRRRRRRRR
 QQQQQQ     QQQQQQ   QQQQQQ     QQQQQQ   RRRRRRRRRRRRRRRRRR
  QQQQQQ   QQQQQQ     QQQQQQ  QQQQQQQ    RRRRRR   RRRRRR
   QQQQQQQQQQQQQ  QQ   QQQQQQQQQQQQQ     RRRRRR    RRRRRR
     QQQQQQQQQ   QQQQ    QQQQQQQQQQ      RRRRRR     RRRRRR
       QQQQQ    QQQQQQ      QQQQQ        RRRRRR      RRRRRR

===============================================================================
                          Welcome to oQoRun Launcher
===============================================================================

=========================== DISCLAIMER / EULA ==================================
 [!] WARNING: READ BEFORE USE

 1. This is open-source software provided "AS IS", without warranty of any kind.
 2. It is strictly for EDUCATIONAL, LEARNING, and TESTING purposes only.
 3. Ensure you have the rights to use any models loaded into this software.
 4. The author/developer assumes absolutely NO RESPONSIBILITY or LIABILITY for
    any computer security issues, privacy leaks, hardware damage, or abuse.
 5. By proceeding to use this application, you accept all risks entirely upon
    yourself and agree to these terms.
================================================================================

# oQoRun User Manual

oQoRun is a lightweight, local Large Language Model (LLM) launcher and chat interface featuring Live Preview. With oQoRun, you can safely run any open-source AI model locally on your computer and perfectly render HTML, CSS, and JavaScript code in your conversations.

---

## 🚀 Prerequisites: What you need to install "Manually"

To minimize file size and avoid copyright issues, this software package **does NOT include the AI engine itself nor the AI models**. Before using it, ensure you have manually prepared the following three items:

### 1. Install Node.js (Required Environment)
The oQoRun backend server requires Node.js to run.
* **Download:** Go to the [Node.js Official Website](https://nodejs.org/) and download/install the **LTS (Long Term Support)** version.
* **Verify Installation:** Restart your computer or command prompt after installation, and type `node -v` to check if it was installed successfully.

### 2. Prepare the Llama.cpp Engine (AI Core)
Since everyone's hardware is different (CPU only, NVIDIA/AMD GPU, etc.), you must download the engine that suits your system.
* **Download:** Search for and download a compiled release of **`llama.cpp`** (e.g., pre-built binaries from their GitHub Releases page).
* **Location:** Inside your oQoRun folder, create a new folder named `llama-b8101-bin-win-cpu-x64` (If you use a different name, please update the folder path reference inside `server.js`).
* **Required Files:** Ensure that the file `llama-server.exe` is placed directly inside this folder.

### 3. Download GGUF Format AI Models
This is the "brain" of the AI. Without it, the AI cannot answer questions.
* **Download:** Go to Hugging Face to find models you like (We recommend searching for models with Coding / Math capabilities to fully utilize the live code preview feature). The format must be a `.gguf` file.
* **Location:** Inside your oQoRun folder, create a new folder named `models`.
* **Storage:** Place all downloaded `.gguf` files into this `models` folder.

---

## 📦 System Startup: What will run "Automatically"?

Once you have prepared the three items above, simply right-click (or double-click) the following file in the folder:
👉 **`oQoRun.bat`**

Upon first execution, the command prompt will display the EULA. Enter `Y` to agree, and the **system will automatically perform the following** for you:

1. **Automatically download all required dependencies**
   - Since the original package does not include `node_modules`, the script will automatically call `npm install express cross-spawn cors` to build the required library environment.
   - This is fully automated and requires no manual coding.
2. **Automatically set up the local chat web server**
3. **Automatically open `http://localhost:3000` in your default browser**

---

## ⚙️ How to use the Launcher

1. **Select a Core Model:** In the sidebar with the rainbow logo, click the dropdown menu. The system will automatically list all model files located in your `models` folder.
2. **Customize Performance Parameters:** Click "⚙️ Settings" at the bottom left. If you have a powerful graphics card and an engine that supports CUDA, it is highly recommended to set **GPU Acceleration** to a non-zero value (e.g., Max GPU Offload) inside the settings. This accelerates generation speed tremendously!
3. **Launch the AI:** After modifying parameters, return to the sidebar, select your preferred model name, and oQoRun will automatically call the Llama.cpp engine to load the model for you. Wait until the green `Connected` light appears at the top of the screen, and you can start chatting!
4. **Live Preview:** Ask the AI to write something like "an HTML page with a heart button". Not only will it generate the code, but it will also create a handy thumbnail icon button in the right sidebar. Click that icon to view the source code securely in a modal and immediately see the live rendered browser preview!
